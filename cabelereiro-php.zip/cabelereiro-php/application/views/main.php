<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- HEADER -->
<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
       <a class="navbar-brand" href="#">FERNANDO CABELEREIRO</a>
        
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
              
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-lg-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#home">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#servicos">Serviços</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#equipe">Perfil</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="#contact">Contato</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#localizacao">Localização</a>
                </li>
            </ul>    
        </div>
    </div>
</nav>
</header>

<!-- BANNER -->
<div class="jumbotron jumbotron-fluid height100p banner" id="home">
<div class="container h100">
    <div class="contentBox h100">
        <div>
            <!-- Successo submit -->
            <?php if(isset($debug)): ?>
                <div class="alert alert-success" role="alert" id="messaggio" >
                    <?php echo $debug;  ?>
                </div>
            <?php endif; ?>

            <h1 data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">PRODUÇÃO DE NOIVAS</h1>
            <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">Lorem ipsum dolor 
            sit amet, consectetur adipisicing elit. </p>
        </div>
    </div>
</div>
</div>

<!-- SERVICES AREA -->
<section class="sec1" id="servicos">
    <div class="container">
        <div class="row">
            <div class="offset-sm-2 col-sm-8">
                <div class="headerText text-center">
                    <h2 data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">Áreas de atuação</h2>
                    <p data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">Nosso escritório 
                        atende a uma pauta variada de demandas, englobando, assim, diversas áreas do
                        Direito, tais quais:
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <div class="placeBox" data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/capello-1.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>PREVIDENCIÁRIO <br><span></span></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="placeBox" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/capello-4.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>TRABALHISTA <br><span></span></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="placeBox" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/capello-3.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>DIREITO CIVIL <br><span></span></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- PERFIL AREA --> 
<section class="sec2" id="adventure">
    <div class="container h100">
        <div class="contentBox h100">
            <div>
                <h1 data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">EVENTOS</h1>
                <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">Crivelli Advogados
                    destaca-se como um dos maiores escritórios do país especializados em direito
                    sindical, trabalhista e previdenciário, com um atendimento integral e de 
                    excelência a nossos clientes numa reafirmação diária do compromisso histórico
                    com a luta pelos direitos dos trabalhadores. Ética, transparência e absoluta
                        fidelidade aos direitos humanos são cláusulas imutáveis do escritório.
                </p>
                <a href="#" class="btn btnD1" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">Leia mais</a>
            </div>
        </div>
    </div>
</section>


<!-- SECTION BLOG -->
<section class="blog" id="equipe">
    <div class="container">
        <div class="row">
            <div class="offset-sm-2 col-sm-8">
                <div class="headerText">
                    <h2 data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">EQUIPE</h2>
                    <p data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                        Crivelli Advogados
                        destaca-se como um dos maiores escritórios do país especializados em direito
                        sindical, trabalhista e previdenciário, com um atendimento integral e de 
                        excelência a nossos clientes numa reafirmação diária do compromisso histórico
                        com a luta pelos direitos dos trabalhadores. Ética, transparência e absoluta
                        fidelidade aos direitos humanos são cláusulas imutáveis do escritório.
                    </p>
                
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/capello-2.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Dr Tal</h1>
                        <p>Lorem ipsum dolor sit, amet consectetur 
                            adipisicing elit. Ab sint deserunt ipsum ratione
                            officia ex obcaecati vitae, vel atque quo delectus!
                            Veniam, alias. Quibusdam dolorum quis impedit 
                            laboriosam, assumenda architecto.</p>
                            <a href="#" class="btn btnD2">Read More</a>
                            <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/capello-2.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Dr Tal</h1>
                        <p>Lorem ipsum dolor sit, amet consectetur 
                            adipisicing elit. Ab sint deserunt ipsum ratione
                            officia ex obcaecati vitae, vel atque quo delectus!
                            Veniam, alias. Quibusdam dolorum quis impedit 
                            laboriosam, assumenda architecto.</p>
                        <a href="#" class="btn btnD2">Read More</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/capello-1.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Dr Tal</h1>
                        <p>Lorem ipsum dolor sit, amet consectetur 
                            adipisicing elit. Ab sint deserunt ipsum ratione
                            officia ex obcaecati vitae, vel atque quo delectus!
                            Veniam, alias. Quibusdam dolorum quis impedit 
                            laboriosam, assumenda architecto.</p>
                        <a href="#" class="btn btnD2">Read More</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1000">
                    <div class="imgBx">
                        <img src="<?php echo base_url('assets/img/capello-3.jpg') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="content">
                        <h1>Dr Tal</h1>
                        <p>Lorem ipsum dolor sit, amet consectetur 
                            adipisicing elit. Ab sint deserunt ipsum ratione
                            officia ex obcaecati vitae, vel atque quo delectus!
                            Veniam, alias. Quibusdam dolorum quis impedit 
                            laboriosam, assumenda architecto.</p>
                            <a href="#" class="btn btnD2">Read More</a>
                            <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SECTION CONTACT -->
<section class="contact" id="contact">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="headerText text-center">
                    <h2 data-aos="fade-up" data-aos-delay="0" data-aos-duration="0">Entre em contato</h2>
                    <p data-aos="fade-up" data-aos-delay="0" data-aos-duration="0">Lorem, ipsum dolor 
                        sit amet consectetur adipisicing elit.
                        Laborum aliquam quasi architecto doloremque nostrum
                        tempore quo dolorum corrupti quos impedit.</p>
                </div>
            </div>
        </div>
        <div class="row clearfix" data-aos="fade-up" data-aos-delay="0" data-aos-duration="1000">
            <div class="offset-sm-2 col-sm-8">
                <form action="<?php echo site_url('main/insert_message') ?>" method="post">
                    <div class="form-group">
                        <label for="">Nome</label>
                        <input type="text" name="text-nome" class="form-control" required>

                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" name="text-email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Telefone</label>
                        <input type="text"  name="text-telefone" class="form-control" id="telefone" required>
                    </div>
                    <div class="form-group">
                        <label for="">Message</label>
                        <textarea class="form-control" name="text-message" id="" cols="30" rows="10" required></textarea>
                    </div>
                    <div class="form-group">
                        <button class="btn btnD1">Enviar</button>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
</section>

<!-- LOCALIZAÇAO AREA --> 
<section class="blog" id="localizacao">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="blogpost" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <div class="imgBx">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3980.9748350057675!2d-38.497834685960825!3d-3.8155139972243814!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x7c74f928229fb7d%3A0xa0fc59418c085fce!2sR.%20Ara%C3%BAjo%20Torre%C3%A3o%2C%20547%20-%20Messejana%2C%20Fortaleza%20-%20CE%2C%2060841-470!5e0!3m2!1spt-BR!2sbr!4v1569242056034!5m2!1spt-BR!2sbr" width="100%" height="350px" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                    </div>
                    <div class="content">
                        <h1>Localização</h1>
                        <p>Lorem ipsum dolor sit, amet consectetur 
                            adipisicing elit. Ab sint deserunt ipsum ratione
                            officia ex obcaecati vitae, vel atque quo delectus!
                            Veniam, alias. Quibusdam dolorum quis impedit 
                            laboriosam, assumenda architecto.</p>
                            <!-- <a href="#" class="btn btnD2">Read More</a> --> 
                            <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>  
    </div>  
</section>

<!-- FOOTER -->
<footer>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <ul class="sci">
                <!-- Use fontawesome -->
                <li><a href="#"><i class="fa fa-facebook"></i> </a> </li>
                <li><a href="#"><i class="fa fa-twitter"></i> </a> </li>
                <li><a href="#"><i class="fa fa-google-plus"></i> </a> </li>
                <li><a href="#"><i class="fa fa-instagram"></i> </a> </li>
                <li><a href="#"><i class="fa fa-youtube"></i> </a> </li>
                
            </ul>
            <p class="cpryt">
                @ Copyright 2019 Nature | Template by <a href="#"> Anthonio Lior</a> 
            </p>
        </div>
    </div>
</div>
</footer>

