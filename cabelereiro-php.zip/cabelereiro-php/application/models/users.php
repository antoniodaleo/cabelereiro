<?php
defined('BASEPATH') OR exit('URL inválido');

class Users extends CI_Model{
    
    public function comento(){
        $dados = array(
            'nome' =>$this->input->post('text-nome'),
            'email' => $this->input->post('text-email'),
            'telefone' => $this->input->post('text-telefone'), 
            'message' => $this->input->post('text-message')
        );
        $this->db->insert('cliente', $dados); 


        
    }
   

}
?>