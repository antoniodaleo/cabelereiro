<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	/**
	 
	 */
	public function index()
	{
		$this->load->view('layouts/head');
		$this->load->view('main');
		$this->load->view('layouts/end'); 
	}

	public function insert_message(){
		

		$data['successo'] = ''; 
		if($this->input->method()!== 'post'){
			
						
		}else{
			$this->load->model('users');
			$this->users->comento(); 
			$data['successo'] = 'Mesagem enviada com sucesso!!';
			
			$this->load->library('email'); 
			$this->email->from('antoniodaleo@outlook.com'); 
			$this->email->to('lletycia@hotmail.it'); 
			$this->email->subject('ultimo teste'); 
			$this->email->message('
				<html lang="pt">
				<head>
					<meta charset="UTF-8">
					<meta name="viewport" content="width=device-width, initial-scale=1.0">
					<meta http-equiv="X-UA-Compatible" content="ie=edge">
				
					<title>Template estudo de advocacia</title>
					
					<!-- CDN Font-awesome - Vers. 4.7.0 -->
					<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
					
					<!-- CDN Bootstrap - Vers. 4.3.1 -->
					<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
					<link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
					<!-- Foglio di stile personalizzato -->
				</head>
				<body>
				<h1>ultimo test display pulito</h1>
				
				</body>
				</html>
			');
	
			if($this->email->send()){
				$dados['debug'] = 'Mensagem enviada com sucesso'; 
			}else{
				$arrResult['respose'] ='error'; 
				$dados['debug'] = 'Email nao enviada'.$arrResult; 
			}

			$this->load->view('layouts/head');
			$this->load->view('main',$dados);
            $this->load->view('layouts/end');
            
            //$result = $this->send(); 
           // print_r($result); 
		}

		
    }
	
}


